# Datasheet: Teen Screen Time & Wellbeing (10k, Synthetic)

## Motivation

**What is this dataset for?**
Practicing classification, regression and exploratory analysis on teenagers aged 13-19 across 10 countries. Primary target `high_anxiety`; secondary target `anxiety_score`.

**Why was it created?**
Many public tabular datasets lack a clean target or are full of missing values. This one is complete, documented and leakage-aware.

## Composition

**What do the instances represent?**
Each row is one synthetic teenager. No real entities are described.

**How many instances?** 10,000

**What data does each instance consist of?**
18 columns: identifiers (teen_id), features, outcome columns (anxiety_score, high_anxiety).

**Is there a label or target?**
Yes. `high_anxiety` is binary (25.0% positive); `anxiety_score` is continuous and right-skewed (log-transform recommended).

**Missing data?** None.

**Recommended splits:** random stratified split on `high_anxiety`; rows are independent.

## Collection Process

**How was the data created?**
Synthetically generated with NumPy/pandas (seed 3001). A latent quality variable and context variables drive the features; outcomes are derived with logistic / log-normal links plus noise. `high_anxiety` = 1 if the simulated anxiety score is in the top 25%.

## Preprocessing

None. Data is generated in its final format.

## Uses

**Suitable:** teaching, benchmarking, notebooks, EDA practice, evaluating leakage-awareness.
**Not suitable:** drawing conclusions about real teens, real-world forecasting, or commercial decisions.

## Limitations

Relationships are programmatic and cleaner than real-world data. Names are random and not real. Outcome columns are deterministic-ish functions of the latent variables, so do not use them as features for `high_anxiety`.

## Distribution and License

CC0 Public Domain.

## Maintenance

Maintained by the author on Kaggle (vedauv).
