# Teen Screen Time & Wellbeing (10k, Synthetic)

> **Synthetic dataset.** Every row was generated with Python to mimic teenagers aged 13-19 across 10 countries. It contains no real teens and no personal data. Patterns reflect how the generator was built, not the real world. This is a statistical simulation, not a medical, psychological or HR study. Do not use it to draw conclusions about real people. Anxiety scores are simulated on a 0-21 scale and are not clinical measures.

## What is this?

A teenager dataset with a clear prediction target. **10,000 rows, 18 columns, one CSV (~693 kB).** `high_anxiety` = 1 if the simulated anxiety score is in the top 25%.

## Why should you use it?

- **Clean, complete data**: no missing values, no joins needed
- **Two targets**: `high_anxiety` (classification) and `anxiety_score` (regression)
- **Leakage practice**: outcome columns are clearly separated so you can practice avoiding target leakage
- **Fast to start, still interesting**: nonlinear effects, interactions and noise, so tuned models beat simple baselines
- **Universal appeal**: a relatable topic that is easy to explain and visualize

## Columns

| Column | Type | Description |
|--------|------|-------------|
| `teen_id` | int | Unique identifier |
| `age` | int | Age (13-19) |
| `gender` | int | Female, Male or Non-binary |
| `country` | int | Country (10 groups) |
| `primary_platform` | int | Most-used platform |
| `parental_controls` | int | 1 if parental controls are on |
| `daily_screen_hours` | float | Recreational screen hours per day |
| `social_media_hours` | float | Social media hours per day |
| `gaming_hours` | float | Gaming hours per day |
| `night_phone_min` | int | Phone minutes after bedtime |
| `notifications_per_day` | int | Notifications received per day |
| `sleep_hours` | float | Average sleep hours |
| `physical_activity_min` | int | Physical activity minutes per day |
| `close_friends` | int | Number of close friends |
| `family_time_hours` | float | Family time hours per day |
| `school_grade_avg` | int | Average school grade (35-100) |
| `anxiety_score` | int | Simulated anxiety score 0-21 (regression target, outcome) |
| `high_anxiety` | int | **Classification target**: 1 if top-25% score |

**Outcome columns (do not use as features when predicting `high_anxiety`):** `anxiety_score`, `high_anxiety`

## Suggested Tasks

- **Classification:** predict `high_anxiety` (drop `anxiety_score`)
- **Regression:** predict `anxiety_score`
- **Analysis:** how do sleep and night-time phone use interact?
- **Platforms:** compare platforms after controlling for hours
- **Interpretable ML:** which few features give most of the predictive power?

## Quick Start

```python
import pandas as pd

df = pd.read_csv("teen_screen_time.csv")
print(df.shape)
print(f"Positive rate of high_anxiety: {df['high_anxiety'].mean():.1%}")

outcomes = ['anxiety_score', 'high_anxiety']
X = df.drop(columns=['teen_id'] + outcomes)   # 15 launch-time features
y = df["high_anxiety"]
```

## How the data was generated

A hidden "quality" variable plus marketing/context variables drive the features, and the outcomes follow from them through logistic and log-normal relationships with random noise. Random seed: 3001. Treat conclusions as properties of the generator, which makes this a good sandbox for practicing modelling, EDA and evaluation.

## License

CC0 Public Domain
